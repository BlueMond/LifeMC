LifeMC
======

LifeMC allows you to implement a complex life system into Minecraft. Every new player will start out with a default amount of lives. 

When a player is out of lives, he or she will be banned until that player regains a life. Players can pay eachother in lives. 


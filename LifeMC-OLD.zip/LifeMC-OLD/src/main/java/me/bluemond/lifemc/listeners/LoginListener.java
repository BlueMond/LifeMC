package me.bluemond.lifemc.listeners;

import me.bluemond.lifemc.LifeMC;
import me.bluemond.lifemc.lang.Lang;
import org.bukkit.GameMode;
import org.bukkit.ChatColor;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

//Listener class
public class LoginListener implements Listener {

	private LifeMC plugin;

	public LoginListener(LifeMC instance) {
		plugin = instance;
	}

	@EventHandler
	public void onPlayerLogin(PlayerLoginEvent event) {
		final Player player = event.getPlayer();

		if (!plugin.getDataHandler().isStored(player.getName())) {
			// Store new player

			plugin.getDataHandler().setLives(player, plugin.getConfigHandler().getStartingLives());
		}

		plugin.getServer().getScheduler()
			.runTaskLater(plugin, new Runnable() {
				public void run() {
					player.setGameMode(GameMode.SURVIVAL);
				}
			}, 20L);

	}
}